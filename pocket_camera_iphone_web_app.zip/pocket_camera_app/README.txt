POCKET CAMERA — iPhone Home Screen web app starter

WHAT IT DOES
- Lets you select a video from the iPhone Photos picker.
- Plays the selected video inside a camera-style preview.
- Includes play/pause, restart, mute, zoom-style preview controls, and a timer.
- Does not access the live camera or save a newly recorded video.

TO USE IT ON IPHONE
1. Publish the contents of this folder to a static HTTPS website (for example, a static site host).
2. Open the published website URL in Safari on your iPhone.
3. Tap Share (the square with the upward arrow).
4. Choose “Add to Home Screen”.
5. Enable “Open as Web App” if that option appears, then tap Add.

IMPORTANT
This ZIP is a starter project, not a published website or native App Store app.
It must be hosted at an HTTPS URL before Safari can add it as a Home Screen web app.
